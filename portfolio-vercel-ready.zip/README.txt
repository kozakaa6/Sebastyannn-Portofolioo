PORTFOLIO — VERCEL DEPLOY

This is a static website. The complete site is in index.html.
No Node.js, npm install, or build step is required.

DEPLOY WITH VERCEL:
1. Extract this ZIP.
2. Put the extracted files in a GitHub repository (index.html must be at the repository root).
3. Open https://vercel.com/new and sign in.
4. Import the GitHub repository.
5. In the project setup, choose Other if a framework is requested.
6. Leave Build Command and Output Directory empty/default for a static site.
7. Click Deploy. Vercel will provide the public URL.

You can also deploy the extracted folder using the Vercel CLI:
  npm i -g vercel
  cd portfolio-vercel-ready
  vercel

The original uploaded archive contained only index.html. The site is preserved as supplied.
